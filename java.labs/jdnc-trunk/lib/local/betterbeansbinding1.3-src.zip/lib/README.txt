This should be removed as we find the required files in some Maven repository.
