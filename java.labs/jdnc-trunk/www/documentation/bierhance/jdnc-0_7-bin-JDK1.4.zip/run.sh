#!/bin/sh
#
# Script for running jdnc applications
# 
# Usage: run.sh <filename> <logging>
# Where:
# <filename> : The path to a .jdnc file
# <logging>  : Logging level [ severe | warning | info | fine ] default is warning

JAR_LOCATION=lib

CPATH=classes
for filename in `/bin/ls $JAR_LOCATION`; do
    extension=${filename##*.}
    if [ $extension = jar ]; then
	CPATH=$CPATH:$JAR_LOCATION/$filename
    fi
done

$JAVA_HOME/bin/java -cp $CPATH org.jdesktop.jdnc.runner.Application ${1} ${2}
